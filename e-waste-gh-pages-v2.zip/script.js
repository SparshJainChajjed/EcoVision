let model,imageDataUrl=null;
const sampleDevices=[
  {name:"Smartphone",originalValue:"₹50,000",currentValue:"₹5,000"},
  {name:"Laptop",originalValue:"₹70,000",currentValue:"₹15,000"},
  {name:"Tablet",originalValue:"₹30,000",currentValue:"₹7,000"},
  {name:"Desktop PC",originalValue:"₹40,000",currentValue:"₹8,000"}
];
const directory={
  bengaluru:{
    ngos:[
      {name:"Saahas Zero Waste",site:"https://saahaszerowaste.com/",phone:"+91-80-4168-9889"},
      {name:"Share At Door Step (pickup)",site:"https://shareatdoorstep.com/donate/computer-e-waste/",phone:""},
      {name:"BBMP E‑Waste Collection (info)",site:"https://bbmp.gov.in/",phone:""}
    ],
    recyclers:[
      {name:"Zolopik Recycling",site:"https://zolopik.com/",phone:"+91-8884449985"},
      {name:"E‑Parisaraa Pvt. Ltd.",site:"https://www.eparisaraa.com/",phone:"+91-80-2836-7770"},
      {name:"Namo E‑Waste (serviceable)",site:"https://www.namoe-waste.com/",phone:"1800-123-445555"}
    ]
  },
  default:{
    ngos:[
      {name:"Share At Door Step (pickup)",site:"https://shareatdoorstep.com/donate/computer-e-waste/",phone:""},
      {name:"Local Municipal E‑Waste Info",site:"https://www.india.gov.in/topics/environment-forests/e-waste",phone:""},
      {name:"Karo Sambhav Collection Finder",site:"https://www.karosambhav.com/",phone:""}
    ],
    recyclers:[
      {name:"Zolopik Recycling",site:"https://zolopik.com/",phone:"+91-8884449985"},
      {name:"Recycler Directory (CPCB)",site:"https://cpcb.nic.in/e-waste/",phone:""},
      {name:"Producer Responsibility Orgs",site:"https://moefcc.gov.in/",phone:""}
    ]
  }
};
const modelStatus=document.getElementById("modelStatus");
const imageInput=document.getElementById("imageInput");
const identifyBtn=document.getElementById("identifyBtn");
const preview=document.getElementById("preview");
const resultSection=document.getElementById("resultSection");
const deviceNameEl=document.getElementById("deviceName");
const originalValueEl=document.getElementById("originalValue");
const currentValueEl=document.getElementById("currentValue");
const recycleSection=document.getElementById("recycleSection");
const optionsSection=document.getElementById("optionsSection");
const recycleBtn=document.getElementById("recycleBtn");
const skipBtn=document.getElementById("skipBtn");
const locationStatus=document.getElementById("locationStatus");
const manualLocation=document.getElementById("manualLocation");
const cityInput=document.getElementById("cityInput");
const applyCity=document.getElementById("applyCity");
const manualChooser=document.getElementById("manualChooser");
const manualCategory=document.getElementById("manualCategory");
const applyManual=document.getElementById("applyManual");
function mapToCategory(label){
  const l=label.toLowerCase();
  if(l.includes("laptop")||l.includes("notebook"))return"Laptop";
  if(l.includes("cellular")||l.includes("mobile")||l.includes("smartphone")||l.includes("telephone")||l.includes("ipod"))return"Smartphone";
  if(l.includes("monitor")||l.includes("desktop")||l.includes("screen"))return"Desktop PC";
  if(l.includes("tablet")||l.includes("ipad")||l.includes("book jacket"))return"Tablet";
  return null;
}
function pickDeviceFor(label){
  const mapped=mapToCategory(label);
  if(mapped)return sampleDevices.find(d=>d.name===mapped);
  return sampleDevices[Math.floor(Math.random()*sampleDevices.length)];
}
async function ensureModel(){
  if(model)return true;
  try{
    modelStatus.textContent="Loading model…";
    model=await mobilenet.load();
    modelStatus.textContent="Model ready.";
    return true;
  }catch(e){
    modelStatus.textContent="Model failed to load. Use manual picker below.";
    manualChooser.style.display="grid";
    return false;
  }
}
function setDevice(device){
  deviceNameEl.textContent=device.name;
  originalValueEl.textContent=device.originalValue;
  currentValueEl.textContent=device.currentValue;
  resultSection.style.display="block";
  recycleSection.style.display="block";
}
imageInput.addEventListener("change",()=>{
  const f=imageInput.files[0];
  if(!f){preview.style.display="none";imageDataUrl=null;return;}
  const reader=new FileReader();
  reader.onload=e=>{imageDataUrl=e.target.result;preview.src=imageDataUrl;preview.style.display="block";};
  reader.readAsDataURL(f);
});
identifyBtn.addEventListener("click",async()=>{
  if(!imageDataUrl){modelStatus.textContent="Choose an image first.";manualChooser.style.display="grid";return;}
  const ok=await ensureModel();
  if(ok){
    try{
      modelStatus.textContent="Identifying…";
      const p=await model.classify(preview);
      const top=p&&p[0]?p[0].className:"unknown";
      const device=pickDeviceFor(top);
      setDevice(device);
      modelStatus.textContent="Done.";
      manualChooser.style.display="grid";
    }catch(e){
      modelStatus.textContent="Identification failed. Use manual picker.";
      manualChooser.style.display="grid";
    }
  }
});
applyManual.addEventListener("click",()=>{
  const v=manualCategory.value;
  if(!v)return;
  const device=sampleDevices.find(d=>d.name===v)||sampleDevices[0];
  setDevice(device);
});
function inBengaluru(lat,lon){
  return lat>=12.80&&lat<=13.20&&lon>=77.40&&lon<=77.80;
}
function cityKeyFromText(t){
  if(!t)return"default";
  const s=t.toLowerCase();
  if(s.includes("bengaluru")||s.includes("bangalore"))return"bengaluru";
  return"default";
}
function renderDirectory(key){
  const dir=document.getElementById("directory");
  const data=directory[key]||directory.default;
  const cards=[];
  data.ngos.forEach(x=>{
    cards.push(`<div class="dir-card"><h4>NGO</h4><p>${x.name}</p><a href="${x.site}" target="_blank">${x.site}</a>${x.phone?`<p>${x.phone}</p>`:""}</div>`);
  });
  data.recyclers.forEach(x=>{
    cards.push(`<div class="dir-card"><h4>Recycler</h4><p>${x.name}</p><a href="${x.site}" target="_blank">${x.site}</a>${x.phone?`<p>${x.phone}</p>`:""}</div>`);
  });
  dir.innerHTML=cards.join("");
  optionsSection.style.display="block";
}
recycleBtn.addEventListener("click",()=>{
  if("geolocation"in navigator){
    locationStatus.textContent="Detecting your location…";
    navigator.geolocation.getCurrentPosition(
      pos=>{
        const{latitude,longitude}=pos.coords;
        locationStatus.textContent=`Location detected (${latitude.toFixed(2)}, ${longitude.toFixed(2)}).`;
        const key=inBengaluru(latitude,longitude)?"bengaluru":"default";
        renderDirectory(key);
      },
      err=>{
        locationStatus.textContent="Unable to get location. Enter city below.";
        manualLocation.style.display="grid";
      }
    );
  }else{
    locationStatus.textContent="Geolocation not supported. Enter city below.";
    manualLocation.style.display="grid";
  }
});
applyCity.addEventListener("click",()=>{
  const key=cityKeyFromText(cityInput.value);
  renderDirectory(key);
});
skipBtn.addEventListener("click",e=>{
  e.preventDefault();
  resultSection.style.display="none";
  recycleSection.style.display="none";
  optionsSection.style.display="none";
  document.getElementById("directory").innerHTML="";
  preview.style.display="none";
  imageInput.value=null;
  imageDataUrl=null;
  modelStatus.textContent="Ready.";
});
